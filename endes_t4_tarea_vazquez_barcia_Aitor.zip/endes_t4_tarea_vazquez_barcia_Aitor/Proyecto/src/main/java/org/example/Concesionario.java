package org.example;
/**
 * Aitor Vazquez Barcia.
 */

import java.util.ArrayList;

/**
 * Este es  un concesionario de autos.
 */
public class Concesionario {
    /**
     * Listado de autos en el concesionario.
     */
    private ArrayList<Auto> autos;

    /**
     * realiza una nueva instancia de Concesionario.
     */
    public Concesionario() {
        autos = new ArrayList<Auto>();
    }

    /**
     * introduce un auto al concesionario.
     *
     * @param auto El auto a agregar.
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

    /**
     * Obtiene la lista de autos en el concesionario.
     *
     * @return La lista de autos en el concesionario.
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

    /**
     * Imprime los autos en el concesionario.
     */
    public void imprimirAutos() {
        for (Auto auto : autos) {
            System.out.println(auto);
        }
    }
}
